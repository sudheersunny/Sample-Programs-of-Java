package online;
import java.util.Scanner;
public class triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		int A,B,C;
		System.out.println("Enter the angle of A");
		A=scanner.nextInt();
		System.out.println("Enter the angle of B");
		B=scanner.nextInt();
		System.out.println("Enter the angle of C");
		C=scanner.nextInt();
		if ((A+B>C) && (B+C>A) && (C+A>B)) {
			if(A+B+C==180) {
			System.out.println("The Triangle is Valid");
		}
		else {
			System.out.println("The triangle is not valid");
		}

	}
	}
}
