package online;
import java.util.Scanner;
public class calpercentage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		double quantity,price,amount,discount;
		System.out.println("Enter the product quantity");
		quantity=scanner.nextDouble();
		System.out.println("Enter the price of a product");
		price=scanner.nextDouble();
		amount=quantity*price;
		if(amount>5000) {
			discount=amount*0.1;
			amount=amount-discount;
			System.out.println("the total price of the product is"+amount);
		}
		else {
			System.out.println("the total price of the product is "+amount);
		}
		
		

	}

}
