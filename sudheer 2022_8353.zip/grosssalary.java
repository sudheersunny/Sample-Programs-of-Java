package online;
import java.util.Scanner;
public class grosssalary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the gross salary");
		int salary = scanner.nextInt();
		float grosssalary, hra,da;
		
		if(salary<1500) {
			hra=salary*1/10;
			da=salary*90/100;
			grosssalary=hra+da+salary;
			System.out.println("the gross salary is "+grosssalary);
		}
		else if(salary>=1500) {
			hra=1500;
			da=salary*90/100;
			grosssalary=hra+da+salary;
			System.out.println("the gross salary is "+grosssalary);
		}
		else {
		System.out.println("it is invalid");
		}
		
	}
}
