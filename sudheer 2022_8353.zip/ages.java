package online;
import java.util.Scanner;
public class ages {
	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the ram age");
		int ram=scanner.nextInt();
		System.out.println("enter the sulabh age");
		int sulabh=scanner.nextInt();
		System.out.println("enter the ajay age");
		int ajay=scanner.nextInt();
		
		if((ram<sulabh) && (ram<ajay)){
			System.out.println("the ram is younger");
		}
		else if((sulabh<ram)  && (sulabh<ajay)) {
			System.out.println("the sulabh is younger");
		}
		
		else if((ajay<sulabh)  && (ajay<ram)) {
			System.out.println("the ajay is younger");
		}


		
		
	}

}
