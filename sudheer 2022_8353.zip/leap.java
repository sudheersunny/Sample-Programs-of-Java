package online;
import java.util.Scanner;
public class leap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter the year ");
		int year=scanner.nextInt();
		
		if((year%400==0) && (year%100==0) && (year%4==0)) {
			System.out.println("this year is a leap year"+year);
		}
		else {
			System.out.println("this year is not a leap year"+year);
		}

	}

}
