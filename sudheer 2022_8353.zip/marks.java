package online;
import java.util.Scanner;
public class marks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the 5 subject marks");
		int tel,hin,eng,maths,sci;
		System.out.println("enter the telugu marks");
		tel=scanner.nextInt();
		System.out.println("enter the hindi marks");
		hin=scanner.nextInt();
		System.out.println("enter the english marks");
		eng=scanner.nextInt();
		System.out.println("enter the maths marks");
		maths=scanner.nextInt();
		System.out.println("enter the science marks");
		sci=scanner.nextInt();
		
		int total=tel+hin+eng+maths+sci;
		float percentage=total/5;
		
		if(percentage>=60 && percentage<=100) {
			System.out.println("First Division");
		}
		else if(percentage>=50 && percentage<=59) {
			System.out.println("Second division");
		}
		else if(percentage>=40 && percentage<=49) {
			System.out.println("Third Division");
		}
		else if(percentage>0  && percentage<=39) {
			System.out.println("Fail");
		}
		else {
			System.out.println("invalid input");
		}
		

	}

}
