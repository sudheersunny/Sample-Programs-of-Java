package online;
import java.util.Scanner;
public class absolute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the number");
		int num1=scanner.nextInt();
		
		if(num1<0) {
			int abs=-num1;
			System.out.println("the absolute value is "+abs);
		}
		else {
			System.out.println("the absolute value is num1:"+num1);
		}
	}
}
