package online;
import java.util.Scanner;
public class telephonebills {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the telephone calls");
		int calls =scanner.nextInt();
		double billingamount=0;
		
		if(calls>0  && calls<=100) {
			
			billingamount=200;
		}
		else if(calls>100  && calls<=150) {
			calls =calls-150;
			billingamount=200+(calls*0.60);
		}
		else if(calls>150  && calls<=200) {
			calls-=200;
			billingamount=200+(calls*0.50)*(calls*0.60);
		}
		else if(calls>200) {
			billingamount=200+(calls*0.40)*(calls*0.50)*(calls*0.60);
		}
		System.out.println("the Billing amount is :"+billingamount);
	}
}
