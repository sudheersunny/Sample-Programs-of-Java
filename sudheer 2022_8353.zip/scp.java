package online;
import java.util.Scanner;
public class scp {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner= new Scanner(System.in);
		System.out.println("enter the selling price amount");
		int sp=scanner.nextInt();
		System.out.println("enter the cost price amount");
		int cp=scanner.nextInt();
		
		
		int profit,loss;
		
		if(sp>cp) {
			System.out.println("it is a profit");
		}
		else if(sp<cp) {
			System.out.println("It is a loss");
		}
		else {
			System.out.println("no profit no loss");
		}
			
		}

	}
